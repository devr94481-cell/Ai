# DevLyricX AI Starter

Simple AI website starter project.

## Features
- Purple Void Theme
- Login/Register UI
- AI Chat UI
- File Upload UI
- Theme System
- GitHub Ready

## Run

```bash
npm install
npm run dev
```

## Deploy
Upload to GitHub then connect with Vercel.
